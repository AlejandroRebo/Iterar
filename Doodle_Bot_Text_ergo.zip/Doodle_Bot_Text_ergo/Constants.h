#define lowbat     45    // flat battery voltage
#define charsize    1    // charactor size


