#define Rdirpin  8    // Right motor direction control pin
#define Rpwmpin 10    // Right motor pulse width modulation pin
#define Ldirpin  7    // Left  motor direction control pin
#define Lpwmpin  9    // Left  motor pulse width modulation pin
#define Srvopin 12    // Servo to raise / lower pen

#define Battery  7    // Battery voltage monitor pin (analog input)
